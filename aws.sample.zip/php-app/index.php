<h1>I'm running PHP on Apache</h1>
<pre>PHP Version: <?= phpversion() ?></pre>
